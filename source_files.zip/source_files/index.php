<!doctype html>
<html class="no-js" lang="en">

    <head>
        <!-- meta data -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

        <!--font-family-->
		<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
        
        <!-- title of site -->
        <title>Couch Potato</title>

        <!-- For favicon png -->
		<link rel="shortcut icon" type="image/icon" href="assets/logo/favicon.png"/>
       
        <!--font-awesome.min.css-->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!--linear icon css-->
		<link rel="stylesheet" href="assets/css/linearicons.css">

		<!--animate.css-->
        <link rel="stylesheet" href="assets/css/animate.css">

        <!--owl.carousel.css-->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
		<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
		
        <!--bootstrap.min.css-->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- bootsnav -->
		<link rel="stylesheet" href="assets/css/bootsnav.css" >	
        
        <!--style.css-->
        <link rel="stylesheet" href="assets/css/style.css">
        
        <!--responsive.css-->
        <link rel="stylesheet" href="assets/css/responsive.css">
        
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		
        <!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->

    </head>
	
	<body>
		<!--[if lte IE 9]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
        <![endif]-->
		
		
	
		<!--welcome-hero start -->
		<header id="home" class="welcome-hero">

			<div id="header-carousel" class="carousel slide carousel-fade" data-ride="carousel">
				<!--/.carousel-indicator -->
				 <ol class="carousel-indicators">
					<li data-target="#header-carousel" data-slide-to="0" class="active"><span class="small-circle"></span></li>
					<li data-target="#header-carousel" data-slide-to="1"><span class="small-circle"></span></li>
					<li data-target="#header-carousel" data-slide-to="2"><span class="small-circle"></span></li>
				</ol><!-- /ol-->
				<!--/.carousel-indicator -->

				<!--/.carousel-inner -->
				<div class="carousel-inner" role="listbox">
					<!-- .item -->
					<div class="item active">
						<div class="single-slide-item slide1">
							<div class="container">
								<div class="welcome-hero-content">
									<div class="row">
										<div class="col-sm-7">
											<div class="single-welcome-hero">
												<div class="welcome-hero-txt">
													<h4>great design collection</h4>
													<h2>cloth covered accent chair</h2>
													<p>
														Using Jaipur wood, we have created a simple design chair. Adding a pop of colour into any room.
													</p>
													<div class="packages-price">
														<p>
															Rs. 10,000.00
															<del>Rs. 13,000.00</del>
														</p>
													</div>
													<button class="btn-cart welcome-add-cart" onclick="window.location.href='mainshop3.php'">
														<span class="lnr lnr-plus-circle"></span>
														Shop <span>here</span> 
													</button>
													
												</div><!--/.welcome-hero-txt-->
											</div><!--/.single-welcome-hero-->
										</div><!--/.col-->
										<div class="col-sm-5">
											<div class="single-welcome-hero">
												<div class="welcome-hero-img">
													<img src="assets/images/slider/slider1.png" alt="slider image">
												</div><!--/.welcome-hero-txt-->
											</div><!--/.single-welcome-hero-->
										</div><!--/.col-->
									</div><!--/.row-->
								</div><!--/.welcome-hero-content-->
							</div><!-- /.container-->
						</div><!-- /.single-slide-item-->

					</div><!-- /.item .active-->

					<div class="item">
						<div class="single-slide-item slide2">
							<div class="container">
								<div class="welcome-hero-content">
									<div class="row">
										<div class="col-sm-7">
											<div class="single-welcome-hero">
												<div class="welcome-hero-txt">
													<h4>great design collection</h4>
													<h2>maple wood accent chair</h2>
													<p>
														Originating from the forests of Canada. Made from strong maple wood, perfect for a basic living room mood. Available in grey, red and mustard.
													</p>
													<div class="packages-price">
														<p>
															Rs. 19999.00
															<del>Rs. 29999.00</del>
														</p>
													</div>
													<button class="btn-cart welcome-add-cart" onclick="window.location.href='mainshop3.php'">
														<span class="lnr lnr-plus-circle"></span>
														Shop <span>here</span> 
													</button>
												</div><!--/.welcome-hero-txt-->
											</div><!--/.single-welcome-hero-->
										</div><!--/.col-->
										<div class="col-sm-5">
											<div class="single-welcome-hero">
												<div class="welcome-hero-img">
													<img src="assets/images/slider/slider2.png" alt="slider image">
												</div><!--/.welcome-hero-txt-->
											</div><!--/.single-welcome-hero-->
										</div><!--/.col-->
									</div><!--/.row-->
								</div><!--/.welcome-hero-content-->
							</div><!-- /.container-->
						</div><!-- /.single-slide-item-->

					</div><!-- /.item .active-->

					<div class="item">
						<div class="single-slide-item slide3">
							<div class="container">
								<div class="welcome-hero-content">
									<div class="row">
										<div class="col-sm-7">
											<div class="single-welcome-hero">
												<div class="welcome-hero-txt">
													<h4>great design collection</h4>
													<h2>velvet accent arm chair</h2>
													<p>
														Comfort at its simplest. Adds a minute royal feel to any room. Available in green, off-white, purple.
													</p>
													<div class="packages-price">
														<p>
															Rs. 29999.00
															<del>Rs. 39999.00</del>
														</p>
													</div>
													<button class="btn-cart welcome-add-cart" onclick="window.location.href='mainshop3.php'">
														<span class="lnr lnr-plus-circle"></span>
														Shop <span>here</span> 
													</button>
												</div><!--/.welcome-hero-txt-->
											</div><!--/.single-welcome-hero-->
										</div><!--/.col-->
										<div class="col-sm-5">
											<div class="single-welcome-hero">
												<div class="welcome-hero-img">
													<img src="assets/images/slider/slider3.png" alt="slider image">
												</div><!--/.welcome-hero-txt-->
											</div><!--/.single-welcome-hero-->
										</div><!--/.col-->
									</div><!--/.row-->
								</div><!--/.welcome-hero-content-->
							</div><!-- /.container-->
						</div><!-- /.single-slide-item-->
						
					</div><!-- /.item .active-->
				</div><!-- /.carousel-inner-->

			</div><!--/#header-carousel-->

			<!-- top-area Start -->
			<div class="top-area">
				<div class="header-area">
					<!-- Start Navigation -->
				    <nav class="navbar navbar-default bootsnav  navbar-sticky navbar-scrollspy"  data-minus-value-desktop="70" data-minus-value-mobile="55" data-speed="1000">

				        <!-- Start Top Search -->
				        <div class="top-search">
				            <div class="container">
				                <div class="input-group">
				                    <span class="input-group-addon"><i class="fa fa-search"></i></span>
				                    <input type="text" class="form-control" placeholder="Search">
				                    <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
				                </div>
				            </div>
				        </div>
				        <!-- End Top Search -->

				        <div class="container">            
				            <!-- Start Atribute Navigation -->
				            <div class="attr-nav">
				                <ul>
				                	
				              
				                </ul>
				            </div><!--/.attr-nav-->
				            <!-- End Atribute Navigation -->

				            <!-- Start Header Navigation -->
				            <div class="navbar-header">
				                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
				                    <i class="fa fa-bars"></i>
				                </button>
				                <a class="navbar-brand" href="index.php">Couch<span> Potato</span>.</a>

				            </div><!--/.navbar-header-->
				            <!-- End Header Navigation -->

				            <!-- Collect the nav links, forms, and other content for toggling -->
				            <div class="collapse navbar-collapse menu-ui-design" id="navbar-menu">
				                <ul class="nav navbar-nav navbar-center" data-in="fadeInDown" data-out="fadeOutUp">
				                    <li class=" scroll active"><a href="#home">home</a></li>
				                    <li class="scroll"><a href="#new-arrivals">new arrival</a></li>
				                    <li class="scroll"><a href="#feature">features</a></li>
				                    <li class="scroll"><a href="#blog">blog</a></li>
				                    <li class="scroll"><a href="#clients">contact</a></li>
									<li class="scroll"><input type="button" value="Shop Here" onclick="window.location.href='mainshop3.php'" class="shop-btn" style="padding-top:45px; width:100px;"></li>

				                </ul><!--/.nav -->
				            </div><!-- /.navbar-collapse -->
				        </div><!--/.container-->
				    </nav><!--/nav-->
				    <!-- End Navigation -->
				</div><!--/.header-area-->
			    <div class="clearfix"></div>

			</div><!-- /.top-area-->
			<!-- top-area End -->

		</header><!--/.welcome-hero-->
		<!--welcome-hero end -->

		<!--populer-products start -->
		<section id="populer-products" class="populer-products">
			<div class="container">
				<div class="populer-products-content">
					<div class="row">
						<div class="col-md-3">
							<div class="single-populer-products">
								<div class="single-populer-product-img mt40">
									<img src="assets/images/populer-products/p1.png" alt="populer-products images">
								</div>
								<h2><a href="chairfake.php">arm chair</a></h2>
								<div class="single-populer-products-para">
									<p>Available in many varieties. Comfortable, durable and sleek.</p>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="single-populer-products">
								<div class="single-inner-populer-products">
									<div class="row">
										<div class="col-md-4 col-sm-12">
											<div class="single-inner-populer-product-img">
												<img src="assets/images/populer-products/p2.png" alt="populer-products images">
											</div>
										</div>
										<div class="col-md-8 col-sm-12">
											<div class="single-inner-populer-product-txt">
												<h2>
													<a href="#">
														latest designed stool <span>and</span> chair
													</a>
												</h2>
												<p>
													
												<div class="populer-products-price">
													<h4 style="color:orange;">Sales Start from Rs. 999.00</h4>
												</div>
												<button class="btn-cart welcome-add-cart populer-products-btn" onclick="window.location.href='mainshop3.php'">
													discover more
												</button>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-3">
							<div class="single-populer-products">
								<div class="single-populer-products">
									<div class="single-populer-product-img">
										<img src="assets/images/populer-products/p3.png" alt="populer-products images">
									</div>
									<h2><a href="mainshop3.php">hanging lamp</a></h2>
									<div class="single-populer-products-para">
										<p>White & Grey/Gold Mosaic Glass Hanging Lamps</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div><!--/.container-->

		</section><!--/.populer-products-->
		<!--populer-products end-->

		<!--new-arrivals start -->
		<section id="new-arrivals" class="new-arrivals">
			<div class="container">
				<div class="section-header">
					<h2>new arrivals</h2>
				</div><!--/.section-header-->
				<div class="new-arrivals-content">
					<div class="row">
						<div class="col-md-3 col-sm-4">
							<div class="single-new-arrival">
								<div class="single-new-arrival-bg">
									<img src="assets/images/collection/arrivals1.png" alt="new-arrivals images">
									<div class="single-new-arrival-bg-overlay"></div>
									<div class="sale bg-1">
										<p>sale</p>
									</div>
								
								</div>
								<h4><a href="hexagonchair.php">hexagon chair</a></h4>
								<p class="arrival-product-price">Rs. 9000.00</p>
							</div>
						</div>
						<div class="col-md-3 col-sm-4">
							<div class="single-new-arrival">
								<div class="single-new-arrival-bg">
									<img src="assets/images/collection/arrivals2.png" alt="new-arrivals images">
									<div class="single-new-arrival-bg-overlay"></div>
									<div class="sale bg-2">
										<p>sale</p>
									</div>
									
								</div>
								<h4><a href="sofafake.php">single armchair</a></h4>
								<p class="arrival-product-price">Rs. 18000.00</p>
							</div>
						</div>
						<div class="col-md-3 col-sm-4">
							<div class="single-new-arrival">
								<div class="single-new-arrival-bg">
									<img src="assets/images/collection/arrivals3.png" alt="new-arrivals images">
									<div class="single-new-arrival-bg-overlay"></div>
									
								</div>
								<h4><a href="chair_rocking.php">rocking chair</a></h4>
								<p class="arrival-product-price">Rs. 10100.00</p>
							</div>
						</div>
						<div class="col-md-3 col-sm-4">
							<div class="single-new-arrival">
								<div class="single-new-arrival-bg">
									<img src="assets/images/collection/arrivals4.png" alt="new-arrivals images">
									<div class="single-new-arrival-bg-overlay"></div>
									<div class="sale bg-1">
										<p>sale</p>
									</div>
									
								</div>
								<h4><a href="chair_dalmation.php">dalmation chair</a></h4>
								<p class="arrival-product-price">Rs. 10000.00</p>
							</div>
						</div>
						<div class="col-md-3 col-sm-4">
							<div class="single-new-arrival">
								<div class="single-new-arrival-bg">
									<img src="assets/images/collection/arrivals5.png" alt="new-arrivals images">
									<div class="single-new-arrival-bg-overlay"></div>
									
								</div>
								<h4><a href="chair_redvelvet.php">red-velvet chair</a></h4>
								<p class="arrival-product-price">Rs. 5700.00</p>
							</div>
						</div>
						<div class="col-md-3 col-sm-4">
							<div class="single-new-arrival">
								<div class="single-new-arrival-bg">
									<img src="assets/images/collection/arrivals6.png" alt="new-arrivals images">
									<div class="single-new-arrival-bg-overlay"></div>
									<div class="sale bg-1">
										<p>sale</p>
									</div>
									
								</div>
								<h4><a href="tablefake.php">mapple wood dinning table</a></h4>
								<p class="arrival-product-price">Rs. 25000.00</p>
							</div>
						</div>
						<div class="col-md-3 col-sm-4">
							<div class="single-new-arrival">
								<div class="single-new-arrival-bg">
									<img src="assets/images/collection/arrivals7.png" alt="new-arrivals images">
									<div class="single-new-arrival-bg-overlay"></div>
									<div class="sale bg-2">
										<p>sale</p>
									</div>
								
								</div>
								<h4><a href="chairfake.php">arm chair</a></h4>
								<p class="arrival-product-price">Rs. 10000.00</p>
							</div>
						</div>
						<div class="col-md-3 col-sm-4">
							<div class="single-new-arrival">
								<div class="single-new-arrival-bg">
									<img src="assets/images/collection/arrivals8.png" alt="new-arrivals images">
									<div class="single-new-arrival-bg-overlay"></div>
									
								</div>
								<h4><a href="bed_box.php">box bed</a></h4>
								<p class="arrival-product-price">Rs. 30000.00</p>
							</div>
						</div>
					</div>
				</div>
			</div><!--/.container-->
		
		</section><!--/.new-arrivals-->
		<!--new-arrivals end -->

		<!--sofa-collection start -->
		<section id="sofa-collection">
			<div class="owl-carousel owl-theme" id="collection-carousel">
				<div class="sofa-collection collectionbg1">
					<div class="container">
						<div class="sofa-collection-txt">
							<h2>Sofa collection</h2>
							<p>Explore Eclectic Sofas Collection at CouchPotatoes For Your Modern Home. Sofas, being the heart of any house, need to be chosen mindfully. It is our comfort zone where we spend most of our quality time. We offer an extensive range of sofas to choose from.</p>
							<div class="sofa-collection-price">
								<h4>strting from <span>Rs 19999</span></h4>
							</div>
						
						</div>
					</div>	
				</div><!--/.sofa-collection-->
				<div class="sofa-collection collectionbg2">
					<div class="container">
						<div class="sofa-collection-txt">
							<h2>Dining table collection</h2>
							<p>
								Vast Selection of Products from chic brands. Choose from our large selection of wood, metal or glass tables in a set or individually. Explore now.
							</p>
							<div class="sofa-collection-price">
								<h4>strting from <span>Rs. 29999</span></h4>
							</div>
							
						</div>
					</div>
				</div><!--/.sofa-collection-->
			</div><!--/.collection-carousel-->

		</section><!--/.sofa-collection-->
		<!--sofa-collection end -->

		<!--feature start -->
		<section id="feature" class="feature">
			<div class="container">
				<div class="section-header">
					<h2>featured products</h2>
				</div><!--/.section-header-->
				<div class="feature-content">
					<div class="row">
						<div class="col-sm-3">
							<div class="single-feature">
								<img src="assets/images/features/f1.jpg" alt="feature image">
								<div class="single-feature-txt text-center">
									<p>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<span class="spacial-feature-icon"><i class="fa fa-star"></i></span>
										<span class="feature-review">(45 review)</span>
									</p>
									<h3><a href="sofafake.php">designed sofa</a></h3>
									<h5>Rs. 16000.00</h5>
								</div>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="single-feature">
								<img src="assets/images/features/f2.jpg" alt="feature image">
								<div class="single-feature-txt text-center">
									<p>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<span class="spacial-feature-icon"><i class="fa fa-star"></i></span>
										<span class="feature-review">(45 review)</span>
									</p>
									<h3><a href="tablefake.php">dinning table </a></h3>
									<h5>Rs. 20000.00</h5>
								</div>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="single-feature">
								<img src="assets/images/features/f3.jpg" alt="feature image">
								<div class="single-feature-txt text-center">
									<p>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<span class="spacial-feature-icon"><i class="fa fa-star"></i></span>
										<span class="feature-review">(45 review)</span>
									</p>
									<h3><a href="chairfake.php">chair and table</a></h3>
									<h5>Rs. 10000.00</h5>
								</div>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="single-feature">
								<img src="assets/images/features/f4.jpg" alt="feature image">
								<div class="single-feature-txt text-center">
									<p>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<span class="spacial-feature-icon"><i class="fa fa-star"></i></span>
										<span class="feature-review">(45 review)</span>
									</p>
									<h3><a href="chairfake.php">modern arm chair</a></h3>
									<h5>Rs. 29999.00</h5>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div><!--/.container-->

		</section><!--/.feature-->
		<!--feature end -->

		<!--blog start -->
		<section id="blog" class="blog">
			<div class="container">
				<div class="section-header">
					<h2>latest blog</h2>
				</div><!--/.section-header-->
				<div class="blog-content">
					<div class="row">
						<div class="col-sm-4">
							<div class="single-blog">
								<div class="single-blog-img">
									<img src="assets/images/blog/b1.jpg" alt="blog image">
									<div class="single-blog-img-overlay"></div>
								</div>
								<div class="single-blog-txt">
									<h2><a href="#">Tina Rodrigues</a></h2>
									<h3><a href="#">18th March 2023 </a></h3>
									<p>
										I recently had the pleasure of trying out some dining chairs from CouchPotato, and I have to say, I was thoroughly impressed. The selection of chairs was extensive, with a wide range of styles and materials to choose from.
									</p>
								</div>
							</div>
							
						</div>
						<div class="col-sm-4">
							<div class="single-blog">
								<div class="single-blog-img">
									<img src="assets/images/blog/b2.jpg" alt="blog image">
									<div class="single-blog-img-overlay"></div>
								</div>
								<div class="single-blog-txt">
									<h2><a href="#">Robert Norby</a></h2>
									<h3><a href="#">21st December 2022</a></h3>
									<p>
										After trying out a bed from CouchPotato, I have to say that I am thoroughly impressed with my purchase. The bed is comfortable, well-made, and stylish. The customer service was excellent, and the delivery was prompt and hassle-free. I would highly recommend CouchPotato for anyone in the market for a new bed.
									</p>
								</div>
							</div>
						</div>
						<div class="col-sm-4">
							<div class="single-blog">
								<div class="single-blog-img">
									<img src="assets/images/blog/b3.jpg" alt="blog image">
									<div class="single-blog-img-overlay"></div>
								</div>
								<div class="single-blog-txt">
									<h2><a href="#">Mukesh Shah</a></h2>
									<h3><a href="#">9th June 2021 </a></h3>
									<p>
										I recently purchased a lamp from CouchPotato and I am very impressed with its quality and design. The lamp provides a warm, inviting glow and its sleek, modern style adds a touch of elegance to my living room. I would highly recommend CouchPotato for anyone in need of stylish and functional lighting options.
									</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div><!--/.container-->
			
		</section><!--/.blog-->
		<!--blog end -->

		<!-- clients strat -->
		<section id="clients"  class="clients">
			<div class="container">
				<div id="contact" class="contact-us">
					<div class="container">
					  <div class="row">
						<div class="col-lg-12 wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.25s">
						  <form id="contact" method="post" action="add_entry.php"> 
							<div style="height:300px" class="row">
							  <div class="col-lg-6 offset-lg-3">
								<div class="section-heading">
								  <h6 id="validationl1" style="font-size:30px">Reach Out to Us</h6>
								  <p style= "color:#e99c2e; font-size: 20px;">Fill Out The Form Below To <span>Get</span> In Touch With Us</p>
								</div>
							  </div>
							  <fieldset style="border: 5px; border-color: #e99c2e;">
							  <div class="col-lg-9">
								<div class="row">
								  <div class="col-lg-6">
									<fieldset>
									  <input style="float: left;
									  height: 46px;
									  border-radius: 5px;
									  background-color: transparent;
									  border: 2px solid #cac1b7;
									  outline: none;
									  font-size: 15px;
									  font-weight: 300;
									  color: #2a2a2a;
									  padding: 0px 10px;
									  margin-bottom: 20px;" type="name" name="name" id="name" placeholder="Name" autocomplete="on" required>
									</fieldset>
								  </div>
								  <div class="col-lg-6">
									<fieldset>
									  <input style="float: right;
									  height: 46px;
									  border-radius: 5px;
									  background-color: transparent;
									  border: 2px solid #cac1b7;
									  outline: none;
									  font-size: 15px;
									  font-weight: 300;
									  color: #2a2a2a;
									  padding: 0px 10px;
									  margin-bottom: 20px;" type="surname" name="surname" placeholder="Surname" autocomplete="on" required>
									</fieldset>
								  </div>
								  <div class="col-lg-6">
									<fieldset>
									  <input style="float: left;
									  height: 46px;
									  border-radius: 5px;
									  background-color: transparent;
									  border: 2px solid #cac1b7;
									  outline: none;
									  font-size: 15px;
									  font-weight: 300;
									  color: #2a2a2a;
									  padding: 0px 10px;
									  margin-bottom: 20px;" type="text" name="email" pattern="[^ @]*@[^ @]*" placeholder="Your Email" required="">
									</fieldset>
								  </div>
								  <div class="col-lg-6">
									<fieldset>
									  <input style="float: right;
									  height: 46px;
									  border-radius: 5px;
									  background-color: transparent;
									  border: 2px solid #cac1b7;
									  outline: none;
									  font-size: 15px;
									  font-weight: 300;
									  color: #2a2a2a;
									  padding: 0px 10px;
									  
									  margin-bottom: 20px;" type="subject" name="subject" placeholder="Subject" autocomplete="on">
									</fieldset>
								  </div>
								  <div class="col-lg-12">
									<fieldset >
									  <textarea style="width: 100%;
									  min-width: 100%;
									  max-width: 100%;
									  max-height: 180px;
									  min-height: 140px;
									  height: 140px;
									  border-radius: 5px;
									  background-color: transparent;
									  border: 2px solid #e99c2e;
									  outline: none;
									  font-size: 15px;
									  font-weight: 300;
									  color: #2a2a2a;
									  padding: 15px 20px;
									  margin-bottom: 20px;"name="message" type="text" class="form-control" placeholder="Message" required=""></textarea>  
									</fieldset>
								  </div>
								</fieldset>
								  <div class="col-lg-12">
									<fieldset style="padding-top: 10px;">
									  <button style="background-color: #e99c2e; color: #2a2a2a; border-radius: 20px; height: 60px; width: 180px;" type="submit" name="submit">Send Message Now</button>
									</fieldset>
								  </div>
								</div>
							  </div>
							  
							</div>
						  </form>
						</div>
					  </div>
					</div>
				  </div>
					
			</div><!--/.container-->

		</section><!--/.clients-->	
		<!-- clients end -->
			<?php
				include "db_connect.php";
				//echo $mysqli->host_info . "\n";

				//include "display_db.php";
				$mysqli->close();

			?>

			<?php 
			error_reporting(0); 
				
				// Database connection details
				$host = "localhost";
				$username = "root";
				$user_pass = "usbw";
				$database_in_use = "database_foe";

				// Create connection
				$mysqli = mysqli_connect($host,$username,$user_pass,$database_in_use);
								
				// Check connection
				if (!$mysqli) 
				{
					die("Connection failed: " . mysqli_connect_error());
				}

				// Retrieve data from database
				$sql = "SELECT * FROM reachout_table"; // Replace your_table_name with the actual name of your table
				$result = mysqli_query($mysqli, $sql);
				
				// Open a file handle for writing the CSV file
				$csv_file = fopen('reachout_table_data.csv', 'a');
				
				// Write the header row
				$header = array('Name', 'Surname', 'Email', 'Subject', 'Message');
				fputcsv($csv_file, $header);
				
				// Loop through the database data and write to the CSV file
				while($row = mysqli_fetch_assoc($result)) {
					$data = array($row["name"], $row["surname"], $row["email"], $row["subject"], $row["message"]);
					fputcsv($csv_file, $data);
				}
				
				// Close the file handle
				fclose($csv_file);
			
				// Close the database connection
				mysqli_close($mysqli);
				
				


			?>
		<!--newsletter strat -->
		
		<section id="newsletter"  class="newsletter">
			<div class="container">
				<div class="hm-footer-details">
					<div class="row">
						<div class=" col-md-3 col-sm-6 col-xs-12" >
							<div class="hm-footer-widget">
								<div class="hm-foot-title">
									<h4>information</h4>
								</div><!--/.hm-foot-title-->
								<div class="hm-foot-menu">
									<ul>
										<li><a href="#">about us</a></li><!--/li-->
										<li><a href="#clients">contact us</a></li><!--/li-->
						
										<li><a href="mainshop3.php">store</a></li><!--/li-->
									</ul><!--/ul-->
								</div><!--/.hm-foot-menu-->
							</div><!--/.hm-footer-widget-->
						</div><!--/.col-->
						
						<div class=" col-md-3 col-sm-6 col-xs-12">
							 <div class="hm-footer-widget"> 
								 <div class="hm-foot-title"> 
									<h4>Products</h4>
								</div>
								<div class="hm-foot-menu">
									<ul>
										<li><a href="chairfake.php">chair</a></li>
										<li><a href="bedfake.php">bed</a></li>
						
										<li><a href="tablefake.php">table</a></li>
										<li><a href="sofafake.php">sofa</a></li>
									</ul>
								</div>
							 </div>
						</div>
						<div class=" col-md-3 col-sm-6  col-xs-12" >
							<div class="hm-footer-widget">
								<div class="hm-foot-title">
									<h4>newsletter</h4>
								</div><!--/.hm-foot-title-->
								<div class="hm-foot-para">
									<p>
										Subscribe  to get latest news,update and information.
									</p>
								</div><!--/.hm-foot-para-->
								<div class="hm-foot-email">
									<div class="foot-email-box">
										<form id="email_subscribe" method="post" action="add_email.php">
											<input type="email" class="form-control" name="emailsub" placeholder="Enter Email Here....">
											
										
									</div><!--/.foot-email-box-->
									<div class="foot-email-subscribe">
										<span><button type="submit" name="submit"><i class="fa fa-location-arrow"></i></button></span>
									</div><!--/.foot-email-icon-->
								</div></form><!--/.hm-foot-email-->
							</div><!--/.hm-footer-widget-->
						</div><!--/.col-->
					</div><!--/.row-->
				</div><!--/.hm-footer-details-->
 
			</div><!--/.container-->

		</section><!--/newsletter-->	
		
		<!--newsletter end -->

		<!--footer start-->
		<footer id="footer"  class="footer">
			<div class="container">
				<div class="hm-footer-copyright text-center">
					<div class="footer-social">
					<a href="https://www.facebook.com/"><i class="fa fa-facebook"></i></a>	
						<a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a>
						<a href="https://www.linkedin.com/feed/"><i class="fa fa-linkedin"></i></a>
						<a href="https://in.pinterest.com/"><i class="fa fa-pinterest"></i></a>
						<a href="https://www.behance.net/"><i class="fa fa-behance"></i></a>		
					</div>
					
				</div><!--/.text-center-->
			</div><!--/.container-->

			<div id="scroll-Top">
				<div class="return-to-top">
					<i class="fa fa-angle-up " id="scroll-top" data-toggle="tooltip" data-placement="top" title="" data-original-title="Back to Top" aria-hidden="true"></i>
				</div>
				
			</div><!--/.scroll-Top-->
			
        </footer><!--/.footer-->
		<!--footer end-->
		
		<!-- Include all js compiled plugins (below), or include individual files as needed -->

		<script src="assets/js/jquery.js"></script>
        
        <!--modernizr.min.js-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
		
		<!--bootstrap.min.js-->
        <script src="assets/js/bootstrap.min.js"></script>
		
		<!-- bootsnav js -->
		<script src="assets/js/bootsnav.js"></script>

		<!--owl.carousel.js-->
        <script src="assets/js/owl.carousel.min.js"></script>


		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
		
        
        <!--Custom JS-->
        <script src="assets/js/custom.js"></script>
        
    </body>
	
</html>