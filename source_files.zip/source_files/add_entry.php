<?php
    $host = "localhost";
    $username = "root";
    $user_pass = "usbw";
    $database_in_use = "database_foe";

    $mysqli = mysqli_connect($host,$username,$user_pass,$database_in_use);
    
    if(isset($_POST['submit']))
    {    
        $new_name= $_POST["name"];
        $new_surname= $_POST["surname"];
        $new_email= $_POST["email"];
        $new_subject= $_POST["subject"];
        $new_message= $_POST["message"];
        $sqli = "INSERT INTO reachout_table (Name,Surname,Email,Subject,Message) VALUES ('$new_name','$new_surname','$new_email','$new_subject','$new_message')";
        if(mysqli_query($mysqli, $sqli)) 
        {
            echo '<script>alert("Message sent successfully!")</script>';
          } else 
          {
            echo "Error: " . mysqli_error($mysqli);
          }
        mysqli_close($mysqli);
    }
    
?>