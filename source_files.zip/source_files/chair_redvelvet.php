<!doctype html>
<html class="no-js" lang="en">

    <head>
        <!-- meta data -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

        <!--font-family-->
		<link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
        
        <!-- title of site -->
        <title>Couch Potato</title>

        <!-- For favicon png -->
		<link rel="shortcut icon" type="image/icon" href="assets/logo/favicon.png"/>
       
        <!--font-awesome.min.css-->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!--linear icon css-->
		<link rel="stylesheet" href="assets/css/linearicons.css">

		<!--animate.css-->
        <link rel="stylesheet" href="assets/css/animate.css">

        <!--owl.carousel.css-->
        <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
		<link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
		
        <!--bootstrap.min.css-->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- bootsnav -->
		<link rel="stylesheet" href="assets/css/bootsnav.css" >	
        
        <!--style.css-->
        <link rel="stylesheet" href="assets/css/mainshoppg.css">
        
        <!--responsive.css-->
        <link rel="stylesheet" href="assets/css/responsive.css">
        
        <script>
		document.getElementsByTagName("html")[0].className += " js";
	 </script>
	 <link rel="stylesheet" href="new assets/css/style.css">

    </head>
	
	<body>
	
		
		
	
		
	
        <header>
			<!-- top-area Start -->
			<div class="top-area">
				<div class="header-area">
					<!-- Start Navigation -->
				    <nav class="navbar navbar-default bootsnav  navbar-sticky navbar-scrollspy"  data-minus-value-desktop="70" data-minus-value-mobile="55" data-speed="1000">


				        <div class="container">            
				            <!-- Start Atribute Navigation -->
				            <div class="attr-nav">
				                <ul>
				                
				            </div><!--/.attr-nav-->
				            <!-- End Atribute Navigation -->

				            <!-- Start Header Navigation -->
				            <div class="navbar-header">
				                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-menu">
				                    <i class="fa fa-bars"></i>
				                </button>
				                <a class="navbar-brand" href="index.php">Couch<span> Potato</span>.</a>

				            </div><!--/.navbar-header-->
				            <!-- End Header Navigation -->

				            <!-- Collect the nav links, forms, and other content for toggling -->
				            <div class="collapse navbar-collapse menu-ui-design" id="navbar-menu">
				                <ul class="nav navbar-nav navbar-center" data-in="fadeInDown" data-out="fadeOutUp">
				                    <li class=" scroll"><input type="button" value="Home" onclick="window.location.href='index.php'" class="home-btn" style="background-color:white;
    color: #e99c2e;
    padding-top: 47px;
    
    width: 80px;
    height: 70px;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;"></li>
				                   <!-- <li class="scroll active"><a href="mainshop2.php">shop</a></li>-->
									<li data-filter="Sofas"><a href="mainshop3.php">shop</a></li>
				                    
				                </ul><!--/.nav -->
				            </div><!-- /.navbar-collapse -->
				        </div><!--/.container-->
				    </nav><!--/nav-->
				    <!-- End Navigation -->
				</div><!--/.header-area-->
			    <div class="clearfix"></div>

			</div><!-- /.top-area-->
			<!-- top-area End -->

		</header><!--/.welcome-hero-->
		<!--welcome-hero end -->
        
    
            
                <main class="small-container">
				
                    <div class="row">
                        <div class="col-sm-6" style="padding-left: 250px;padding-top: 50px;padding-bottom: 100px;">
                            <img src="assets/images/collection/arrivals5.png" width="250" height="250">
                        </div>
                        <div class="col-sm-6" style="padding-left: 100px; ">
						<br><br>
                            <u><p>Shop /Red Velvet Chair</p></u>
							<p style="font-size: 50px; font-weight: bold;color: #e99c2e;">Red Velvet Chair</p>
							<h4>Rs. 5700</h4><br>
							<p style="font-size: small;padding-right: 100px;text-align: justify;">The red velvet chair is a luxurious and sophisticated seating option that adds a touch of glamour to any room. With its ability to rotate, it offers versatility and functionality to your seating arrangement. 
Its plush velvet upholstery and striking red hue create a bold statement, while the comfortable seat and backrest offer relaxation and comfort.</p>
							<p style="font-size: small;padding-right: 100px;text-align: justify; font-weight: bold;">Height: 40 inches, Width: 22 inches, Depth: 24 inches</p><br>
							<!--Quantity     <input type="number" value="1" style="width:50px; padding-left: 15px;">-->
							
							
							<!-- <button class="btn-cart welcome-add-cart" onclick="window.location.href='#'" >
								<span class="lnr lnr-heart"></span>
								W<span>ishlist </span> 
							</button> -->
							
							<style>
								.btn-cart.welcome-add-cart,.btn-cart.welcome-add-cart.welcome-more-info {
									width: 170px;
									height: 60px;
									line-height: 60px;
									border-radius: 1px;
									font-size: 16px;
									font-weight: 500;
									display: inline-block;
									margin-top: 34px;
									-webkit-transition: 0.3s linear; 
									-moz-transition: 0.3s linear; 
									-ms-transition: 0.3s linear; 
									-o-transition: 0.3s linear; 
									transition: 0.3s linear;
									border: 1px solid #e99c2e;
								}
								.btn-cart.welcome-add-cart span {
									text-transform:  lowercase;
									
								}
								.btn-cart.welcome-add-cart span.lnr.lnr-plus-circle {
									position:  relative;
									top: 0px;
									font-size: 16px;
									margin-right: 5px;
									
								}
								.btn-cart.welcome-add-cart.welcome-more-info{
									color: #e99c2e;
									background: #fff;
									border:#e99c2e;
									
								}
								.btn-cart.welcome-add-cart:hover{
									color: #fff;
									background: #e99c2e;
									border: 1px solid #e99c2e;
								}
								.btn-cart.welcome-add-cart.welcome-more-info:hover{
									color: #e99c2e;
									background: transparent;
									border: 1px solid #e99c2e;
								}
							</style>
						</div>
                    </div>
                <hr>
				<div class="row">
					<div >
						<div class="product-page-review" style="padding-left:50px; width: 50%">
						<form>
						<fieldset class="col-sm-4" style="width:500px ;border: solid 2px #e99c2e; padding-left:50px;padding-top:50px;padding-bottom:50px">
						<h3 style="color: #e99c2e; font-family:'Roboto', sans-serif; font-size: 30px;">Write a Review</h3><br>
							<label for="name">Name:</label><br>
							<input type="text"id="name" name="name" 
										style="
										height: 46px;
										border-radius: 5px;
										background-color: transparent;
										border: 2px solid #cac1b7;
										outline: none;
										font-size: 15px;
										font-weight: 300;
										color: #2a2a2a;
										padding: 0px 10px;
										margin-bottom: 20px;"><br>
							<label for="review">Product Review:</label><br>
							<textarea id="review" name="review" style="
										height: 100px;
										width: 300px;
										border-radius: 5px;
										background-color: transparent;
										border: 2px solid #cac1b7;
										outline: none;
										font-size: 15px;
										font-weight: 300;
										color: #2a2a2a;
										padding: 0px 10px;
										margin-bottom: 20px;"></textarea><br>
							<label for="rating">Product Rating:</label><br>
							<input type="number" id="rating" name="rating" min="1" max="10" style="
										height: 46px;
										border-radius: 5px;
										background-color: transparent;
										border: 2px solid #cac1b7;
										outline: none;
										font-size: 15px;
										font-weight: 300;
										color: #2a2a2a;
										padding: 0px 10px;
										margin-bottom: 20px;"><br>
							<button type="submit" style="background-color: #e99c2e; font-weight:bold;color: #fff; border-radius: 30px; height: 40px; width: 180px;">Submit Review</button>
						</form>
						</fieldset>
					</div>
					<fieldset class="col-sm-8" style=" width:55% ;border: solid 2px #e99c2e; padding-left:50px;padding-top:50px;padding-bottom:50px">
					<div  style="width: 50%">
						<div id="reviews">
						<h2 style="color: #e99c2e; font-family:'Roboto', sans-serif; font-size: 30px;">Reviews:</h2>
						<ul id="review-list"></ul>
						</div>
					</div>
					</fieldset>
				</div>

					<script>
					const nameInput = document.getElementById('name');
					const reviewInput = document.getElementById('review');
					const ratingInput = document.getElementById('rating');
					const reviewList = document.getElementById('review-list');

					// Load previous reviews from localStorage or initialize an empty array
					const reviews = JSON.parse(localStorage.getItem('reviews')) || [];

					// Display existing reviews
					//localStorage.clear();
					reviews.forEach(review => {
						
						const li = document.createElement('li');
						li.textContent = `@${review.name}`;
						reviewList.appendChild(li);
						const ni = document.createElement('ni');
						ni.textContent = ` Rating: ${review.rating}`;
						reviewList.appendChild(ni);
						const mi = document.createElement('mi');
						mi.textContent = ` Review: ${review.text}`;
						reviewList.appendChild(mi);
						const pi = document.createElement('pi');
						pi.textContent = `\n*********************************************************\n`;
						reviewList.appendChild(pi);
						
						
					});

					// Add event listener to the form to handle submission
					document.querySelector('form').addEventListener('submit', (event) => {
						event.preventDefault(); // prevent page reload on submit

						// Get the new review data
						const review = {
						name: nameInput.value,
						text: reviewInput.value,
						rating: ratingInput.value
						};

						// Add the new review to the reviews array and update localStorage
						reviews.push(review);
						localStorage.setItem('reviews', JSON.stringify(reviews));

						// Create a new li element to display the review
						const pi = document.createElement('pi');
						pi.textContent = `\n*********************************************************\n`;
						reviewList.appendChild(pi);
						const li = document.createElement('li');
						li.textContent = `@${review.name}`;
						reviewList.appendChild(li);
						const ni = document.createElement('ni');
						ni.textContent = ` Rating: ${review.rating}`;
						reviewList.appendChild(ni);
						const mi = document.createElement('mi');
						mi.textContent = ` Review: ${review.text}`;
						reviewList.appendChild(mi);

						// Add the new li element to the review list
						
						reviewList.appendChild(li);
						reviewList.appendChild(ni);
						reviewList.appendChild(mi);
						reviewList.appendChild(pi);

						// Clear the form inputs
						nameInput.value = '';
						reviewInput.value = '';
						ratingInput.value = '';
					});
					</script>


				
				
				
				</main>

				


        
           
               

    



		<!--footer start-->
		<footer id="footer"  class="footer">
			<div class="container">
				<div class="hm-footer-copyright text-center">
				<div class="footer-social"><br>
                    <a href="https://www.facebook.com/" style="padding-right: 10px;"><i class="fa fa-facebook"></i></a>	
						<a href="https://www.instagram.com/" style="padding-right: 10px;"><i class="fa fa-instagram"></i></a>
						<a href="https://www.linkedin.com/feed/" style="padding-right: 10px;"><i class="fa fa-linkedin"></i></a>
						<a href="https://in.pinterest.com/" style="padding-right: 10px;"><i class="fa fa-pinterest"></i></a>
						<a href="https://www.behance.net/" style="padding-right: 10px;"><i class="fa fa-behance"></i></a>		
					</div>
					
				</div><!--/.text-center-->
			</div><!--/.container-->

			<div id="scroll-Top">
				<div class="return-to-top">
					<i class="fa fa-angle-up " id="scroll-top" data-toggle="tooltip" data-placement="top" title="" data-original-title="Back to Top" aria-hidden="true"></i>
				</div>
				
			</div><!--/.scroll-Top-->
        </div>
        </footer><!--/.footer-->
		<!--footer end-->

		<div class="cd-cart cd-cart--empty js-cd-cart">
			<a href="#0" class="cd-cart__trigger text-replace">
	  
			    <ul class="cd-cart__count">
				   <!-- cart items count -->
				   <li>0</li>
				   <li>0</li>
			    </ul>
			    <!-- .cd-cart__count -->
			</a>
	  
			<div class="cd-cart__content">
			    <div class="cd-cart__layout">
				   <header class="cd-cart__header">
					  <h2>Cart</h2>
					  <span class="cd-cart__undo">Item removed. <a href="#0">Undo</a></span>
				   </header>
	  
				   <div class="cd-cart__body">
					  <ul>
						 <!-- products added to the cart will be inserted here using JavaScript -->
					  </ul>
				   </div>
	  
				   <footer class="cd-cart__footer">
					  <a href="#0" class="cd-cart__checkout">
						 <em>Checkout - $<span>0</span>
				   <svg class="icon icon--sm" viewBox="0 0 24 24"><g fill="none" stroke="currentColor"><line stroke-width="2" stroke-linecap="round" stroke-linejoin="round" x1="3" y1="12" x2="21" y2="12"/><polyline stroke-width="2" stroke-linecap="round" stroke-linejoin="round" points="15,6 21,12 15,18 "/></g>
				   </svg>
				 </em>
					  </a>
				   </footer>
			    </div>
			</div>
			<!-- .cd-cart__content -->
		 </div>
		 <!-- cd-cart -->
		 <script src="new assets/js/util.js"></script>
		 <!-- util functions included in the CodyHouse framework -->
		 <script src="new assets/js/main.js"></script>
		
		
		
		<!-- Include all js compiled plugins (below), or include individual files as needed -->

		<script src="assets/js/jquery.js"></script>
        
        <!--modernizr.min.js-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>
		
		<!--bootstrap.min.js-->
        <script src="assets/js/bootstrap.min.js"></script>
		
		<!-- bootsnav js -->
		<script src="assets/js/bootsnav.js"></script>

		<!--owl.carousel.js-->
        <script src="assets/js/owl.carousel.min.js"></script>


		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
		
        
        <!--Custom JS-->
        <script src="assets/js/custom.js"></script>
        
    </body>
	
</html>

<script type="text/javascript" src="main.js"></script>	