<?php
    $host = "localhost";
    $username = "root";
    $user_pass = "usbw";
    $database_in_use = "database_foe";

    $mysqli = new mysqli($host,$username,$user_pass,$database_in_use);

?>