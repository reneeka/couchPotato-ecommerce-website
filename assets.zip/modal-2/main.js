var count = 0;
function counter() {
    count++;
    console.log(count);
}  